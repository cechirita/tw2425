window.onload = function() {
   
   /* ... */
}

