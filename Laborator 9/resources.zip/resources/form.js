
window.onload = function(){
  
  /* Adăugați cod pentru schimbarea culorii de fundal și 
     pentru eticheta cu valoarea creditului social      */
     
  /* ... */

}

