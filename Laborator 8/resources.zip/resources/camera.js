
window.onload = function(){
    
    /* 
    ... 
    */
}


